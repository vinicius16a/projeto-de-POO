package champList;

public class Habilidade {
	//atributos......................................................................................
	private String nome;
	private String descricao;
	private String tecla;
	
	//construtor......................................................................................
	Habilidade(String nome, String descricao, Champ champ){
		setDescricao(descricao);
		setNome(nome);
		setTecla(View.solicitarString("Digite a qual tecla voce quer atribuir a habilidade"));
	}
	
	

	//get e insert......................................................................................
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if(!nome.isEmpty()) {
			this.nome = nome;
		}else {
			throw new IllegalArgumentException("Nome invalido");
		}
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		if(!descricao.isEmpty()) {
			this.descricao = descricao;
		}else {
			throw new IllegalArgumentException("Descricao invalida, ou vasia");
		}
	}

	public String getTecla() {
		return tecla;
	}

	public void setTecla(String tecla) {
		if(!tecla.isEmpty()) {
			this.tecla = tecla;
		}else {
			throw new IllegalArgumentException("Tecla invalida");
		}
	}
	
	//toString......................................................................................
	public String toString() {
		return "Tecla da habilidade: " + this.tecla + "\nDescrição: " + this.descricao;
	}
	
}
