package champList;

import java.util.ArrayList;

public class Champ {
	//atributos......................................................................................
	private String nome;
	private int dificuldade;
	private String funcao;
	private String descricao;
	private String alcunha;
	private ArrayList<Habilidade> habilidades = new ArrayList<Habilidade>();
	
	//construtor......................................................................................
	Champ(String nome, String funcao){
		setNome(nome);
		setFuncao(funcao);
	}
	
	//Metodos.........................................................................................
	void addHabilidade(Habilidade skill) {
		this.habilidades.add(skill);
	}
	void removerHabilidade(Habilidade skill) {
		this.habilidades.remove(skill);
	}
	
	//toString............................................................................................
	public String toString() {
		return "NOME: " +  this.nome + "   Função: " + this.funcao + " Dificuldade: " + this.dificuldade;
	}
	
	
	//get e insert......................................................................................

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if(!nome.isEmpty()) {
			this.nome = nome;
		}else {
			throw new IllegalArgumentException("Nome invalido");
		}
	}

	public int getDificuldade() {
		return dificuldade;
	}

	public void setDificuldade(int dificuldade) {
		if(dificuldade>=0 && dificuldade<=10) {
			this.dificuldade = dificuldade;
		}else {
			throw new IllegalArgumentException("Dificuldade invalida");
		}
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		if(!funcao.isEmpty()) {
			this.funcao = funcao;
		}else {
			throw new IllegalArgumentException("Funcao invalida");
		}
		
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		if(!descricao.isEmpty()) {
			this.descricao = descricao;
		}else {
			throw new IllegalArgumentException("Descricao invalida, ou vasia");
		}
		
	}

	public String getAlcunha() {
		return alcunha;
	}

	public void setAlcunha(String alcunha) {
		if(!alcunha.isEmpty()) {
			this.alcunha = alcunha;
			
		}else {
			throw new IllegalArgumentException("Alcunha invalida, ou vasia");
		}
		
	}

	public ArrayList<Habilidade> getHabilidades() {
		return habilidades;
	}

	public void setHabilidades(ArrayList<Habilidade> habilidades) {
		this.habilidades = habilidades;
	}
	

}
