package champList;

public class Executora {
	public static void main(String[] args) {
		int op;
		Lista list = new Lista();//criando a lisa que seram armazendos os champs
		
		//menu......................................................................................
		do {
			op = View.solicitarInteiro("Digite 1 para criar um campeão\n" +
					"Digite 2 para remover um campeão\n" +
					"Digite 3 para ir pra lista de campeões adicionados\n"+
					"Digite 0 para encerrar o programa");
			switch (op) {
			case 1:
				try {
					list.criarChamp();
				} catch (Exception e) {
					View.erro(e.getMessage());
				}
				
				break;
				
			case 2:
				list.removerChamp(list.mostrarChamp(View.solicitarString("Digite o nome do campeão que voce deseja remover")));
				break;
			case 3:
				submenu(list);
				break;
			}
		}while(op!=0);
		
	}
	//submenu......................................................................................
	static void submenu(Lista list) {
		int op;
		do {
			op = View.solicitarInteiro("Digite 1 para Listar os campeões adcionados\n" +
					"Digite 2 para Mostrar especificações de um campeão\n" +
					"Digite 0 para voltar ao menu de criação de campeões");
			switch (op) {
			case 1:
				list.champsLista();
				break;
				
			case 2:
				list.mostrarChamp(View.solicitarString("Digite o nome do campeão"));
				break;

			}
		}while(op!=0);
	}
}
