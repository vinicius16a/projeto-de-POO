package champList;

import java.util.ArrayList;
//calsse utilizada para criar a lista de campeões e controla-la

public class Lista {
	private ArrayList<Champ> campeoes = new ArrayList<Champ>();
	//Metodos......................................................................................
	void addChamp(Champ champ) {
		this.campeoes.add(champ);
	}
	
	void removerChamp(Champ champ) {
		this.campeoes.remove(champ);
	}
	void criarChamp() {
		this.campeoes.add(Utils.criarChamp());
	}
	
	
	void champsLista() {
		for (Champ champ : this.campeoes) {
			View.exibirChamp(champ);

		}
	}
	
	Champ mostrarChamp(String nome) {
		boolean encontrei = false;
	
		
		for (Champ champ : this.campeoes) {
	
			if(nome.intern() == champ.getNome().intern()) {
				encontrei = true;
				View.exibirChamp(champ);
				View.exibirMsm("Alcunha:\n", champ.getAlcunha());
				View.exibirMsm("Descrição\n", champ.getDescricao());
				for (Habilidade skill : champ.getHabilidades()) {
					View.exibirHabilidade(skill,skill.getNome());
				}
				return champ;
			}
		}
		
		if(!encontrei) {
			View.erro("Campeão não encontrado");	
		}
		return null;
	}

	//get e insert
	
	public ArrayList<Champ> getCampeoes() {
		return campeoes;
	}

	public void setCampeoes(ArrayList<Champ> campeoes) {
		this.campeoes = campeoes;
	}
	
	
	
}
