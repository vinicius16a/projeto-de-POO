package champList;

import javax.swing.JOptionPane;

public class View {
	static void exibirMsm(String titulo, String msm) {
		JOptionPane.showMessageDialog(null, msm, titulo, JOptionPane.INFORMATION_MESSAGE);
		
	}
	static void exibirChamp(Champ exibir) {
		JOptionPane.showMessageDialog(null, exibir);
	}
	
	static void exibirHabilidade(Habilidade skill, String nome) {
		JOptionPane.showMessageDialog(null, skill, nome, JOptionPane.INFORMATION_MESSAGE);
	}
	
	static String solicitarString(String msm) {
		return JOptionPane.showInputDialog(msm);
	}
	
	static int solicitarInteiro(String msm) {
		String retorno = JOptionPane.showInputDialog(msm);
		return Integer.parseInt(retorno);
	}
	
	static void erro(String msm) {
		JOptionPane.showMessageDialog(null, msm, "erro", JOptionPane.ERROR_MESSAGE);
	}
	

}
