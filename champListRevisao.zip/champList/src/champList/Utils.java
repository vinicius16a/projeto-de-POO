package champList;

public class Utils {
	static Habilidade cirarHabilidade(Champ champ) {
		String nome = View.solicitarString("Digite o nome da habilidade");
		String descricao = View.solicitarString("Digite a descricao da habilidade");
		Habilidade skill = new Habilidade(nome,descricao, champ);
		return skill;
	}
	
	static Champ criarChamp() {
		Habilidade skill;
		int i;
		String nome = View.solicitarString("Digite o nome do campeão");
		String funcao = View.solicitarString("Digite a função do campeão");
		Champ campeao = new Champ(nome,funcao);
		try {
			campeao.setDificuldade(View.solicitarInteiro("Digite a dificuldade do campeão de 1 a 10"));
			campeao.setAlcunha(View.solicitarString("Digite a alcunha do campeão"));
			campeao.setDescricao(View.solicitarString("Digite uma breve descrição do campeão"));
		} catch (IllegalArgumentException e) {
			View.erro(e.getMessage());
		}
		
		for (i=0;i<2;i++) {
			skill = Utils.cirarHabilidade(campeao);
			campeao.addHabilidade(skill);
		}
		return campeao;
	}
}
